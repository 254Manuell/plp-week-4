<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_This course is meant to train young peo_56c251</name>
   <tag></tag>
   <elementGuidId>67f5020e-c443-4cc8-afe2-0b871aae7676</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='scoped-theme-wrapper']/div/div/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;This course is meant to train young people from Africa, starting at a point of l&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7685814f-93bd-40b8-ba8d-35ed7593d614</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>font-[500] text-[14px]</value>
      <webElementGuid>53b89c9d-f83c-470e-968d-41f5ebeafd9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>This course is meant to train young people from Africa, starting at a point of little experience to fairly skilled software developers ready to get into the market place and jump on the next phase of their learning at an advanced levels. </value>
      <webElementGuid>0c7f3f66-bea1-476d-86d4-8f1a7a061f0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;scoped-theme-wrapper&quot;)/div[@class=&quot;gap-5 grid grid-cols-1 md:grid-cols-6&quot;]/div[@class=&quot;relative col-span-4 pb-20 md:h-[calc(100vh-66px)] overflow-y-scroll scroll-smooth no-scrollbar&quot;]/div[@class=&quot;border bg-card text-card-foreground shadow-sm grid grid-cols-6 bg-gradient-to-r from-primary to-secondary p-5 rounded-[12px]&quot;]/div[@class=&quot;space-y-2 col-span-5&quot;]/div[@class=&quot;font-[500] text-[14px]&quot;]</value>
      <webElementGuid>0371a913-b59f-4d3f-b0cd-a4fe00bbab0c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='scoped-theme-wrapper']/div/div/div/div/div[2]</value>
      <webElementGuid>bd042369-0d48-41f3-9bc5-cd5ec7feb496</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Software Development - February 2025 - Cohort VII'])[1]/following::div[1]</value>
      <webElementGuid>d4e38c54-521e-4a1f-be25-4f34933f13d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='emmanuel'])[1]/following::div[9]</value>
      <webElementGuid>f2b8c9e4-dacd-4f7e-a32d-c55e6ef2e623</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[1]/preceding::div[2]</value>
      <webElementGuid>0dc66ade-b32d-434c-9866-2ec98916bfb2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enrolled Modules'])[1]/preceding::div[5]</value>
      <webElementGuid>1c8e4245-2ce3-4edb-a04a-9b587cd39094</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='This course is meant to train young people from Africa, starting at a point of little experience to fairly skilled software developers ready to get into the market place and jump on the next phase of their learning at an advanced levels.']/parent::*</value>
      <webElementGuid>d86d5860-cddd-41fc-a2c4-be822b73f48b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div/div[2]</value>
      <webElementGuid>a4314d10-0aaa-4003-a5e2-3d7f447b3b46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'This course is meant to train young people from Africa, starting at a point of little experience to fairly skilled software developers ready to get into the market place and jump on the next phase of their learning at an advanced levels. ' or . = 'This course is meant to train young people from Africa, starting at a point of little experience to fairly skilled software developers ready to get into the market place and jump on the next phase of their learning at an advanced levels. ')]</value>
      <webElementGuid>f1d6eef5-cf97-4bc9-a623-cfec4fd1e6c2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
